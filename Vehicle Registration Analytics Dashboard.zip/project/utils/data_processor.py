"""
Data Processing Utilities for Vehicle Registration Dashboard
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Tuple
from data.vehicle_data import vehicle_df

class DataProcessor:
    """Process and analyze vehicle registration data"""
    
    def __init__(self):
        self.df = vehicle_df.copy()
        self.df['date'] = pd.to_datetime(self.df['date'])
    
    def filter_data(self, 
                   start_date: str = None, 
                   end_date: str = None,
                   vehicle_types: List[str] = None,
                   manufacturers: List[str] = None) -> pd.DataFrame:
        """Filter data based on criteria"""
        filtered_df = self.df.copy()
        
        if start_date:
            filtered_df = filtered_df[filtered_df['date'] >= start_date]
        if end_date:
            filtered_df = filtered_df[filtered_df['date'] <= end_date]
        if vehicle_types:
            filtered_df = filtered_df[filtered_df['vehicle_type'].isin(vehicle_types)]
        if manufacturers:
            filtered_df = filtered_df[filtered_df['manufacturer'].isin(manufacturers)]
            
        return filtered_df
    
    def get_summary_metrics(self, filtered_df: pd.DataFrame = None) -> Dict:
        """Get summary metrics for dashboard"""
        if filtered_df is None:
            filtered_df = self.df
            
        latest_quarter = filtered_df['quarter'].max()
        latest_data = filtered_df[filtered_df['quarter'] == latest_quarter]
        
        total_registrations = latest_data['registrations'].sum()
        avg_yoy_growth = latest_data['yoy_growth'].mean()
        avg_qoq_growth = latest_data['qoq_growth'].mean()
        
        # Top performer
        top_performer = latest_data.loc[latest_data['yoy_growth'].idxmax()]
        
        return {
            'total_registrations': total_registrations,
            'avg_yoy_growth': avg_yoy_growth,
            'avg_qoq_growth': avg_qoq_growth,
            'top_performer': top_performer['manufacturer'],
            'top_performer_growth': top_performer['yoy_growth']
        }
    
    def get_vehicle_type_summary(self, filtered_df: pd.DataFrame = None) -> pd.DataFrame:
        """Get vehicle type wise summary"""
        if filtered_df is None:
            filtered_df = self.df
            
        latest_quarter = filtered_df['quarter'].max()
        latest_data = filtered_df[filtered_df['quarter'] == latest_quarter]
        
        summary = latest_data.groupby('vehicle_type').agg({
            'registrations': 'sum',
            'yoy_growth': 'mean',
            'qoq_growth': 'mean'
        }).reset_index()
        
        # Calculate market share
        total_registrations = summary['registrations'].sum()
        summary['market_share'] = (summary['registrations'] / total_registrations * 100).round(1)
        
        return summary.sort_values('registrations', ascending=False)
    
    def get_manufacturer_summary(self, filtered_df: pd.DataFrame = None, top_n: int = 10) -> pd.DataFrame:
        """Get manufacturer wise summary"""
        if filtered_df is None:
            filtered_df = self.df
            
        latest_quarter = filtered_df['quarter'].max()
        latest_data = filtered_df[filtered_df['quarter'] == latest_quarter]
        
        summary = latest_data.groupby('manufacturer').agg({
            'registrations': 'sum',
            'yoy_growth': 'mean',
            'qoq_growth': 'mean',
            'vehicle_type': 'first'
        }).reset_index()
        
        return summary.sort_values('registrations', ascending=False).head(top_n)
    
    def get_trend_data(self, filtered_df: pd.DataFrame = None) -> pd.DataFrame:
        """Get trend data for time series analysis"""
        if filtered_df is None:
            filtered_df = self.df
            
        trend_data = filtered_df.groupby(['quarter', 'vehicle_type']).agg({
            'registrations': 'sum',
            'yoy_growth': 'mean',
            'qoq_growth': 'mean'
        }).reset_index()
        
        return trend_data.sort_values('quarter')
    
    def get_growth_leaders(self, metric: str = 'yoy_growth', top_n: int = 5) -> pd.DataFrame:
        """Get top growth performers"""
        latest_quarter = self.df['quarter'].max()
        latest_data = self.df[self.df['quarter'] == latest_quarter]
        
        return latest_data.nlargest(top_n, metric)[['manufacturer', 'vehicle_type', metric, 'registrations']]
    
    def get_investment_insights(self) -> List[Dict]:
        """Generate investment insights"""
        latest_quarter = self.df['quarter'].max()
        latest_data = self.df[self.df['quarter'] == latest_quarter]
        
        insights = []
        
        # Top YoY performer
        top_yoy = latest_data.loc[latest_data['yoy_growth'].idxmax()]
        insights.append({
            'title': 'Growth Champion',
            'description': f"{top_yoy['manufacturer']} leads with {top_yoy['yoy_growth']:.1f}% YoY growth",
            'type': 'positive'
        })
        
        # EV trend
        ev_manufacturers = ['Ola Electric', 'Tata Motors']  # Known EV players
        ev_data = latest_data[latest_data['manufacturer'].isin(ev_manufacturers)]
        if not ev_data.empty:
            avg_ev_growth = ev_data['yoy_growth'].mean()
            insights.append({
                'title': 'EV Revolution',
                'description': f"Electric vehicle manufacturers show {avg_ev_growth:.1f}% average YoY growth",
                'type': 'opportunity'
            })
        
        # Market concentration
        top_5_share = latest_data.nlargest(5, 'registrations')['registrations'].sum()
        total_registrations = latest_data['registrations'].sum()
        concentration = (top_5_share / total_registrations) * 100
        
        insights.append({
            'title': 'Market Concentration',
            'description': f"Top 5 manufacturers control {concentration:.1f}% of registrations",
            'type': 'info'
        })
        
        return insights

# Global processor instance
data_processor = DataProcessor()