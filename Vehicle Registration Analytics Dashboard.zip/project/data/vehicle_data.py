"""
Vehicle Registration Data Module
Simulates Vahan Dashboard data for demonstration purposes
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

class VehicleDataGenerator:
    """Generate realistic vehicle registration data similar to Vahan Dashboard"""
    
    def __init__(self):
        self.manufacturers = {
            '2W': ['Hero MotoCorp', 'Honda', 'Bajaj', 'TVS', 'Royal Enfield', 'Yamaha'],
            '3W': ['Bajaj', 'TVS', 'Mahindra', 'Ola Electric', 'Piaggio'],
            '4W': ['Maruti Suzuki', 'Hyundai', 'Tata Motors', 'Mahindra', 'Kia', 'Toyota']
        }
        
        self.base_registrations = {
            '2W': {'Hero MotoCorp': 145000, 'Honda': 132000, 'Bajaj': 98000, 'TVS': 87000, 'Royal Enfield': 45000, 'Yamaha': 35000},
            '3W': {'Bajaj': 25000, 'TVS': 18000, 'Mahindra': 15000, 'Ola Electric': 12000, 'Piaggio': 8000},
            '4W': {'Maruti Suzuki': 65000, 'Hyundai': 42000, 'Tata Motors': 38000, 'Mahindra': 28000, 'Kia': 22000, 'Toyota': 18000}
        }
    
    def generate_quarterly_data(self) -> pd.DataFrame:
        """Generate quarterly vehicle registration data"""
        data = []
        quarters = [
            ('2023-01-01', 'Q1-2023', 2023),
            ('2023-04-01', 'Q2-2023', 2023),
            ('2023-07-01', 'Q3-2023', 2023),
            ('2023-10-01', 'Q4-2023', 2023),
            ('2024-01-01', 'Q1-2024', 2024),
            ('2024-04-01', 'Q2-2024', 2024)
        ]
        
        for date_str, quarter, year in quarters:
            for vehicle_type, manufacturers in self.manufacturers.items():
                for manufacturer in manufacturers:
                    base_reg = self.base_registrations[vehicle_type].get(manufacturer, 10000)
                    
                    # Add seasonal and growth variations
                    seasonal_factor = self._get_seasonal_factor(quarter)
                    growth_factor = self._get_growth_factor(manufacturer, year)
                    
                    registrations = int(base_reg * seasonal_factor * growth_factor)
                    
                    # Calculate YoY and QoQ growth
                    yoy_growth = self._calculate_yoy_growth(manufacturer, vehicle_type, year, quarter)
                    qoq_growth = self._calculate_qoq_growth(manufacturer, vehicle_type, quarter)
                    
                    data.append({
                        'date': date_str,
                        'quarter': quarter,
                        'year': year,
                        'vehicle_type': vehicle_type,
                        'manufacturer': manufacturer,
                        'registrations': registrations,
                        'yoy_growth': yoy_growth,
                        'qoq_growth': qoq_growth
                    })
        
        return pd.DataFrame(data)
    
    def _get_seasonal_factor(self, quarter: str) -> float:
        """Get seasonal adjustment factor"""
        seasonal_factors = {
            'Q1': 1.1,  # Post-festival season boost
            'Q2': 1.0,  # Normal
            'Q3': 1.05, # Pre-festival
            'Q4': 0.85  # Festival season dip
        }
        quarter_num = quarter.split('-')[0]
        return seasonal_factors.get(quarter_num, 1.0)
    
    def _get_growth_factor(self, manufacturer: str, year: int) -> float:
        """Get growth factor based on manufacturer and year"""
        if year == 2023:
            return 1.0
        
        # Different growth rates for different manufacturers
        growth_rates = {
            'Ola Electric': 1.45,  # High EV growth
            'Royal Enfield': 1.18,  # Premium segment growth
            'Kia': 1.25,  # New entrant growth
            'Tata Motors': 1.15,  # Strong growth
            'TVS': 1.11,  # Steady growth
            'Hero MotoCorp': 1.08,  # Market leader steady growth
            'Honda': 1.06,  # Mature market
            'Bajaj': 1.04,  # Competitive market
            'Maruti Suzuki': 1.05,  # Market leader
            'Hyundai': 1.12,  # Strong performance
            'Mahindra': 1.09,  # Steady growth
            'Toyota': 1.07,  # Conservative growth
            'Yamaha': 1.03,  # Competitive segment
            'Piaggio': 1.06   # Niche player
        }
        
        return growth_rates.get(manufacturer, 1.05)
    
    def _calculate_yoy_growth(self, manufacturer: str, vehicle_type: str, year: int, quarter: str) -> float:
        """Calculate Year-over-Year growth"""
        if year == 2023:
            return np.random.uniform(1.0, 8.0)  # Base year growth
        
        # 2024 growth rates
        if manufacturer == 'Ola Electric':
            return np.random.uniform(40.0, 50.0)
        elif manufacturer == 'Royal Enfield':
            return np.random.uniform(15.0, 22.0)
        elif manufacturer == 'Kia':
            return np.random.uniform(20.0, 30.0)
        elif manufacturer in ['Tata Motors', 'Hyundai']:
            return np.random.uniform(10.0, 18.0)
        else:
            return np.random.uniform(3.0, 12.0)
    
    def _calculate_qoq_growth(self, manufacturer: str, vehicle_type: str, quarter: str) -> float:
        """Calculate Quarter-over-Quarter growth"""
        if 'Q1' in quarter:
            return np.random.uniform(8.0, 25.0)  # Post-festival recovery
        elif 'Q4' in quarter:
            return np.random.uniform(-8.0, 2.0)  # Festival season impact
        else:
            return np.random.uniform(-2.0, 15.0)  # Normal variation

# Global data instance
vehicle_data_generator = VehicleDataGenerator()
vehicle_df = vehicle_data_generator.generate_quarterly_data()