import React, { useState } from 'react';
import { BarChart3, Car, Filter } from 'lucide-react';
import { MetricCard } from './components/MetricCard';
import { FilterPanel } from './components/FilterPanel';
import { VehicleTypeChart } from './components/VehicleTypeChart';
import { ManufacturerChart } from './components/ManufacturerChart';
import { TrendChart } from './components/TrendChart';
import { InsightsPanel } from './components/InsightsPanel';
import { getVehicleTypeData, getManufacturerData } from './data/vehicleData';

function App() {
  const [selectedVehicleTypes, setSelectedVehicleTypes] = useState<string[]>([]);
  const [selectedManufacturers, setSelectedManufacturers] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState({
    start: '2023-01-01',
    end: '2024-12-31'
  });

  const vehicleTypeData = getVehicleTypeData();
  const manufacturerData = getManufacturerData();

  const totalRegistrations = vehicleTypeData.reduce((sum, item) => sum + item.registrations, 0);
  const avgYoYGrowth = vehicleTypeData.reduce((sum, item) => sum + item.yoyGrowth, 0) / vehicleTypeData.length;
  const avgQoQGrowth = vehicleTypeData.reduce((sum, item) => sum + item.qoqGrowth, 0) / vehicleTypeData.length;

  const topManufacturer = manufacturerData.reduce((prev, current) => 
    prev.registrations > current.registrations ? prev : current
  );

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Car className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold">Vahan Analytics Dashboard</h1>
              <p className="text-slate-400 text-sm">Vehicle Registration Intelligence for Investors</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 text-slate-400">
            <BarChart3 size={20} />
            <span className="text-sm">Q1 2024 Data</span>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-80 bg-slate-800 border-r border-slate-700 min-h-screen p-6">
          <FilterPanel
            selectedVehicleTypes={selectedVehicleTypes}
            selectedManufacturers={selectedManufacturers}
            dateRange={dateRange}
            onVehicleTypeChange={setSelectedVehicleTypes}
            onManufacturerChange={setSelectedManufacturers}
            onDateRangeChange={setDateRange}
          />
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <MetricCard
              title="Total Registrations"
              value={Math.round(totalRegistrations / 1000)}
              change={avgYoYGrowth}
              changeType="yoy"
              suffix="K"
            />
            <MetricCard
              title="Average YoY Growth"
              value={avgYoYGrowth.toFixed(1)}
              change={avgYoYGrowth}
              changeType="yoy"
              suffix="%"
            />
            <MetricCard
              title="Quarterly Growth"
              value={avgQoQGrowth.toFixed(1)}
              change={avgQoQGrowth}
              changeType="qoq"
              suffix="%"
            />
            <MetricCard
              title="Market Leader"
              value={topManufacturer.manufacturer.split(' ')[0]}
              change={topManufacturer.yoyGrowth}
              changeType="yoy"
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <VehicleTypeChart />
            <ManufacturerChart 
              selectedManufacturers={selectedManufacturers}
              selectedVehicleTypes={selectedVehicleTypes}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <TrendChart selectedVehicleTypes={selectedVehicleTypes} />
            </div>
            <div>
              <InsightsPanel />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;