export interface VehicleRegistration {
  id: string;
  date: string;
  quarter: string;
  year: number;
  vehicleType: '2W' | '3W' | '4W';
  manufacturer: string;
  registrations: number;
  yoyGrowth: number;
  qoqGrowth: number;
}

export interface ChartDataPoint {
  date: string;
  value: number;
  yoyGrowth: number;
  qoqGrowth: number;
}

export interface ManufacturerData {
  name: string;
  registrations: number;
  yoyGrowth: number;
  qoqGrowth: number;
  marketShare: number;
}

export interface VehicleCategoryData {
  category: '2W' | '3W' | '4W';
  registrations: number;
  yoyGrowth: number;
  qoqGrowth: number;
  marketShare: number;
}