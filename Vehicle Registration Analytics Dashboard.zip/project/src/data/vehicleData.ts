import { VehicleRegistration } from '../types/VehicleData';

// Mock data representing realistic vehicle registration patterns from Vahan Dashboard
export const vehicleRegistrationData: VehicleRegistration[] = [
  // 2W (Two Wheeler) Data
  { id: '1', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '2W', manufacturer: 'Hero MotoCorp', registrations: 145000, yoyGrowth: 8.5, qoqGrowth: 12.3 },
  { id: '2', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '2W', manufacturer: 'Honda', registrations: 132000, yoyGrowth: 6.2, qoqGrowth: 9.8 },
  { id: '3', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '2W', manufacturer: 'Bajaj', registrations: 98000, yoyGrowth: 4.1, qoqGrowth: 7.5 },
  { id: '4', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '2W', manufacturer: 'TVS', registrations: 87000, yoyGrowth: 11.2, qoqGrowth: 15.6 },
  { id: '5', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '2W', manufacturer: 'Royal Enfield', registrations: 45000, yoyGrowth: 18.7, qoqGrowth: 22.1 },

  // 4W (Four Wheeler) Data
  { id: '6', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '4W', manufacturer: 'Maruti Suzuki', registrations: 65000, yoyGrowth: 5.3, qoqGrowth: 8.9 },
  { id: '7', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '4W', manufacturer: 'Hyundai', registrations: 42000, yoyGrowth: 12.8, qoqGrowth: 16.4 },
  { id: '8', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '4W', manufacturer: 'Tata Motors', registrations: 38000, yoyGrowth: 15.2, qoqGrowth: 19.7 },
  { id: '9', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '4W', manufacturer: 'Mahindra', registrations: 28000, yoyGrowth: 9.6, qoqGrowth: 13.2 },
  { id: '10', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '4W', manufacturer: 'Kia', registrations: 22000, yoyGrowth: 25.4, qoqGrowth: 31.8 },

  // 3W (Three Wheeler) Data
  { id: '11', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '3W', manufacturer: 'Bajaj', registrations: 25000, yoyGrowth: 7.8, qoqGrowth: 11.4 },
  { id: '12', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '3W', manufacturer: 'TVS', registrations: 18000, yoyGrowth: 13.5, qoqGrowth: 17.9 },
  { id: '13', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '3W', manufacturer: 'Mahindra', registrations: 15000, yoyGrowth: 6.2, qoqGrowth: 9.8 },
  { id: '14', date: '2024-01-01', quarter: 'Q1-2024', year: 2024, vehicleType: '3W', manufacturer: 'Ola Electric', registrations: 12000, yoyGrowth: 45.7, qoqGrowth: 52.3 },

  // Previous Quarter Data (Q4-2023)
  { id: '15', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '2W', manufacturer: 'Hero MotoCorp', registrations: 129000, yoyGrowth: 3.2, qoqGrowth: -5.1 },
  { id: '16', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '2W', manufacturer: 'Honda', registrations: 120000, yoyGrowth: 2.8, qoqGrowth: -3.7 },
  { id: '17', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '2W', manufacturer: 'Bajaj', registrations: 91000, yoyGrowth: 1.5, qoqGrowth: -2.9 },
  { id: '18', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '2W', manufacturer: 'TVS', registrations: 75000, yoyGrowth: 4.8, qoqGrowth: -1.2 },
  { id: '19', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '2W', manufacturer: 'Royal Enfield', registrations: 37000, yoyGrowth: 12.3, qoqGrowth: 8.9 },

  { id: '20', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '4W', manufacturer: 'Maruti Suzuki', registrations: 59000, yoyGrowth: 2.1, qoqGrowth: -6.8 },
  { id: '21', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '4W', manufacturer: 'Hyundai', registrations: 36000, yoyGrowth: 6.4, qoqGrowth: -2.3 },
  { id: '22', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '4W', manufacturer: 'Tata Motors', registrations: 32000, yoyGrowth: 8.7, qoqGrowth: 3.2 },
  { id: '23', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '4W', manufacturer: 'Mahindra', registrations: 25000, yoyGrowth: 4.5, qoqGrowth: -1.8 },
  { id: '24', date: '2023-10-01', quarter: 'Q4-2023', year: 2023, vehicleType: '4W', manufacturer: 'Kia', registrations: 17000, yoyGrowth: 18.2, qoqGrowth: 12.7 },

  // Previous Year Data (Q1-2023)
  { id: '25', date: '2023-01-01', quarter: 'Q1-2023', year: 2023, vehicleType: '2W', manufacturer: 'Hero MotoCorp', registrations: 133000, yoyGrowth: 2.8, qoqGrowth: 15.6 },
  { id: '26', date: '2023-01-01', quarter: 'Q1-2023', year: 2023, vehicleType: '2W', manufacturer: 'Honda', registrations: 124000, yoyGrowth: 1.9, qoqGrowth: 12.3 },
  { id: '27', date: '2023-01-01', quarter: 'Q1-2023', year: 2023, vehicleType: '4W', manufacturer: 'Maruti Suzuki', registrations: 62000, yoyGrowth: 1.2, qoqGrowth: 8.7 },
  { id: '28', date: '2023-01-01', quarter: 'Q1-2023', year: 2023, vehicleType: '4W', manufacturer: 'Hyundai', registrations: 37000, yoyGrowth: 3.4, qoqGrowth: 11.2 },
];

export const getVehicleTypeData = () => {
  const categoryTotals = vehicleRegistrationData
    .filter(item => item.quarter === 'Q1-2024')
    .reduce((acc, item) => {
      const existing = acc.find(cat => cat.category === item.vehicleType);
      if (existing) {
        existing.registrations += item.registrations;
      } else {
        acc.push({
          category: item.vehicleType,
          registrations: item.registrations,
          yoyGrowth: 0,
          qoqGrowth: 0,
          marketShare: 0
        });
      }
      return acc;
    }, [] as Array<{ category: '2W' | '3W' | '4W', registrations: number, yoyGrowth: number, qoqGrowth: number, marketShare: number }>);

  const totalRegistrations = categoryTotals.reduce((sum, cat) => sum + cat.registrations, 0);
  
  return categoryTotals.map(cat => {
    const currentQuarterData = vehicleRegistrationData
      .filter(item => item.quarter === 'Q1-2024' && item.vehicleType === cat.category);
    const previousQuarterData = vehicleRegistrationData
      .filter(item => item.quarter === 'Q4-2023' && item.vehicleType === cat.category);
    const previousYearData = vehicleRegistrationData
      .filter(item => item.quarter === 'Q1-2023' && item.vehicleType === cat.category);

    const currentTotal = currentQuarterData.reduce((sum, item) => sum + item.registrations, 0);
    const previousQuarterTotal = previousQuarterData.reduce((sum, item) => sum + item.registrations, 0);
    const previousYearTotal = previousYearData.reduce((sum, item) => sum + item.registrations, 0);

    const qoqGrowth = previousQuarterTotal > 0 ? ((currentTotal - previousQuarterTotal) / previousQuarterTotal) * 100 : 0;
    const yoyGrowth = previousYearTotal > 0 ? ((currentTotal - previousYearTotal) / previousYearTotal) * 100 : 0;

    return {
      ...cat,
      registrations: currentTotal,
      yoyGrowth: Math.round(yoyGrowth * 10) / 10,
      qoqGrowth: Math.round(qoqGrowth * 10) / 10,
      marketShare: Math.round((currentTotal / totalRegistrations) * 100 * 10) / 10
    };
  });
};

export const getManufacturerData = () => {
  return vehicleRegistrationData
    .filter(item => item.quarter === 'Q1-2024')
    .sort((a, b) => b.registrations - a.registrations);
};