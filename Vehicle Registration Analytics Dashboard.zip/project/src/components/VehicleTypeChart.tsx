import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { getVehicleTypeData } from '../data/vehicleData';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export function VehicleTypeChart() {
  const vehicleData = getVehicleTypeData();

  const data = {
    labels: vehicleData.map(item => item.category),
    datasets: [
      {
        label: 'Registrations (in thousands)',
        data: vehicleData.map(item => Math.round(item.registrations / 1000)),
        backgroundColor: ['#3B82F6', '#10B981', '#F59E0B'],
        borderColor: ['#2563EB', '#059669', '#D97706'],
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#E2E8F0',
        },
      },
      title: {
        display: true,
        text: 'Vehicle Category Registrations (Q1 2024)',
        color: '#E2E8F0',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          color: '#94A3B8',
        },
        grid: {
          color: '#374151',
        },
      },
      x: {
        ticks: {
          color: '#94A3B8',
        },
        grid: {
          color: '#374151',
        },
      },
    },
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <Bar data={data} options={options} />
    </div>
  );
}