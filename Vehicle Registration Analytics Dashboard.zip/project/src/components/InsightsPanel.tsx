import React from 'react';
import { TrendingUp, Award, AlertTriangle, Lightbulb } from 'lucide-react';
import { getVehicleTypeData, getManufacturerData } from '../data/vehicleData';

export function InsightsPanel() {
  const vehicleTypeData = getVehicleTypeData();
  const manufacturerData = getManufacturerData();

  const topPerformer = manufacturerData.reduce((prev, current) => 
    prev.yoyGrowth > current.yoyGrowth ? prev : current
  );

  const bestCategory = vehicleTypeData.reduce((prev, current) => 
    prev.yoyGrowth > current.yoyGrowth ? prev : current
  );

  const insights = [
    {
      icon: <Award className="text-green-400" size={20} />,
      title: "Growth Champion",
      description: `${topPerformer.manufacturer} leads with ${topPerformer.yoyGrowth}% YoY growth, showing strong market momentum.`,
      type: "positive"
    },
    {
      icon: <TrendingUp className="text-blue-400" size={20} />,
      title: "Category Leader",
      description: `${bestCategory.category} vehicles show ${bestCategory.yoyGrowth}% YoY growth, indicating robust demand.`,
      type: "info"
    },
    {
      icon: <Lightbulb className="text-yellow-400" size={20} />,
      title: "Market Opportunity",
      description: "Electric vehicle manufacturers show exceptional growth rates, indicating a shift in consumer preferences.",
      type: "opportunity"
    },
    {
      icon: <AlertTriangle className="text-orange-400" size={20} />,
      title: "Investment Note",
      description: "Seasonal patterns suggest Q4 typically shows lower registrations due to festival season effects.",
      type: "warning"
    }
  ];

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <h2 className="text-lg font-semibold text-white mb-4">Investment Insights</h2>
      <div className="space-y-4">
        {insights.map((insight, index) => (
          <div key={index} className="bg-slate-700/50 rounded-lg p-4 border border-slate-600">
            <div className="flex items-start space-x-3">
              <div className="mt-0.5">{insight.icon}</div>
              <div>
                <h3 className="font-medium text-white mb-1">{insight.title}</h3>
                <p className="text-slate-300 text-sm">{insight.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}