import React from 'react';
import { Filter, Calendar } from 'lucide-react';

interface FilterPanelProps {
  selectedVehicleTypes: string[];
  selectedManufacturers: string[];
  dateRange: { start: string; end: string };
  onVehicleTypeChange: (types: string[]) => void;
  onManufacturerChange: (manufacturers: string[]) => void;
  onDateRangeChange: (range: { start: string; end: string }) => void;
}

const vehicleTypes = ['2W', '3W', '4W'];
const manufacturers = ['Hero MotoCorp', 'Honda', 'Bajaj', 'TVS', 'Maruti Suzuki', 'Hyundai', 'Tata Motors', 'Mahindra', 'Kia', 'Royal Enfield', 'Ola Electric'];

export function FilterPanel({
  selectedVehicleTypes,
  selectedManufacturers,
  dateRange,
  onVehicleTypeChange,
  onManufacturerChange,
  onDateRangeChange
}: FilterPanelProps) {
  const handleVehicleTypeToggle = (type: string) => {
    const updated = selectedVehicleTypes.includes(type)
      ? selectedVehicleTypes.filter(t => t !== type)
      : [...selectedVehicleTypes, type];
    onVehicleTypeChange(updated);
  };

  const handleManufacturerToggle = (manufacturer: string) => {
    const updated = selectedManufacturers.includes(manufacturer)
      ? selectedManufacturers.filter(m => m !== manufacturer)
      : [...selectedManufacturers, manufacturer];
    onManufacturerChange(updated);
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <div className="flex items-center space-x-2 mb-6">
        <Filter className="text-blue-400" size={20} />
        <h2 className="text-lg font-semibold text-white">Filters</h2>
      </div>

      {/* Date Range */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-3">
          <Calendar className="text-slate-400" size={16} />
          <label className="text-sm font-medium text-slate-300">Date Range</label>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => onDateRangeChange({ ...dateRange, start: e.target.value })}
            className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
          />
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => onDateRangeChange({ ...dateRange, end: e.target.value })}
            className="bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Vehicle Types */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-slate-300 mb-3">Vehicle Categories</label>
        <div className="space-y-2">
          {vehicleTypes.map(type => (
            <label key={type} className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={selectedVehicleTypes.includes(type)}
                onChange={() => handleVehicleTypeToggle(type)}
                className="rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"
              />
              <span className="text-slate-300 text-sm">{type} - {
                type === '2W' ? 'Two Wheeler' : 
                type === '3W' ? 'Three Wheeler' : 
                'Four Wheeler'
              }</span>
            </label>
          ))}
        </div>
      </div>

      {/* Manufacturers */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-3">Manufacturers</label>
        <div className="max-h-48 overflow-y-auto space-y-2">
          {manufacturers.map(manufacturer => (
            <label key={manufacturer} className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={selectedManufacturers.includes(manufacturer)}
                onChange={() => handleManufacturerToggle(manufacturer)}
                className="rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"
              />
              <span className="text-slate-300 text-sm">{manufacturer}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}