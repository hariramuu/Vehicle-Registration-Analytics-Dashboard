import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { vehicleRegistrationData } from '../data/vehicleData';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface TrendChartProps {
  selectedVehicleTypes: string[];
}

export function TrendChart({ selectedVehicleTypes }: TrendChartProps) {
  const quarters = ['Q1-2023', 'Q4-2023', 'Q1-2024'];
  
  const getTrendData = (vehicleType: string) => {
    return quarters.map(quarter => {
      const quarterData = vehicleRegistrationData.filter(
        item => item.quarter === quarter && item.vehicleType === vehicleType
      );
      return quarterData.reduce((sum, item) => sum + item.registrations, 0) / 1000; // Convert to thousands
    });
  };

  const colors = {
    '2W': '#3B82F6',
    '3W': '#10B981',
    '4W': '#F59E0B'
  };

  const datasets = selectedVehicleTypes.length > 0 
    ? selectedVehicleTypes.map(type => ({
        label: `${type} (in thousands)`,
        data: getTrendData(type),
        borderColor: colors[type as keyof typeof colors],
        backgroundColor: colors[type as keyof typeof colors] + '20',
        tension: 0.4,
      }))
    : Object.keys(colors).map(type => ({
        label: `${type} (in thousands)`,
        data: getTrendData(type),
        borderColor: colors[type as keyof typeof colors],
        backgroundColor: colors[type as keyof typeof colors] + '20',
        tension: 0.4,
      }));

  const data = {
    labels: quarters,
    datasets,
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#E2E8F0',
        },
      },
      title: {
        display: true,
        text: 'Registration Trends by Vehicle Category',
        color: '#E2E8F0',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          color: '#94A3B8',
        },
        grid: {
          color: '#374151',
        },
      },
      x: {
        ticks: {
          color: '#94A3B8',
        },
        grid: {
          color: '#374151',
        },
      },
    },
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <Line data={data} options={options} />
    </div>
  );
}