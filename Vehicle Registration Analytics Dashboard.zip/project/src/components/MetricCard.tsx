import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  change: number;
  changeType: 'yoy' | 'qoq';
  prefix?: string;
  suffix?: string;
}

export function MetricCard({ title, value, change, changeType, prefix = '', suffix = '' }: MetricCardProps) {
  const isPositive = change >= 0;
  const changeLabel = changeType === 'yoy' ? 'YoY' : 'QoQ';

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 hover:border-slate-600 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-slate-400 text-sm font-medium">{title}</h3>
        <div className={`flex items-center space-x-1 text-sm ${
          isPositive ? 'text-emerald-400' : 'text-red-400'
        }`}>
          {isPositive ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
          <span>{Math.abs(change)}% {changeLabel}</span>
        </div>
      </div>
      <div className="text-2xl font-bold text-white">
        {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
      </div>
    </div>
  );
}