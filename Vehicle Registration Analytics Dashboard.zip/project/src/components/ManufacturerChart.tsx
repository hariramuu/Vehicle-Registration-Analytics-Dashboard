import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { getManufacturerData } from '../data/vehicleData';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface ManufacturerChartProps {
  selectedManufacturers: string[];
  selectedVehicleTypes: string[];
}

export function ManufacturerChart({ selectedManufacturers, selectedVehicleTypes }: ManufacturerChartProps) {
  const manufacturerData = getManufacturerData()
    .filter(item => 
      (selectedManufacturers.length === 0 || selectedManufacturers.includes(item.manufacturer)) &&
      (selectedVehicleTypes.length === 0 || selectedVehicleTypes.includes(item.vehicleType))
    )
    .slice(0, 10); // Top 10 manufacturers

  const data = {
    labels: manufacturerData.map(item => item.manufacturer),
    datasets: [
      {
        label: 'Registrations (in thousands)',
        data: manufacturerData.map(item => Math.round(item.registrations / 1000)),
        backgroundColor: manufacturerData.map((_, index) => {
          const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#F97316', '#06B6D4', '#84CC16', '#EC4899', '#6366F1'];
          return colors[index % colors.length];
        }),
        borderWidth: 1,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#E2E8F0',
        },
      },
      title: {
        display: true,
        text: 'Top Manufacturers by Registrations (Q1 2024)',
        color: '#E2E8F0',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          color: '#94A3B8',
        },
        grid: {
          color: '#374151',
        },
      },
      x: {
        ticks: {
          color: '#94A3B8',
          maxRotation: 45,
        },
        grid: {
          color: '#374151',
        },
      },
    },
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
      <Bar data={data} options={options} />
    </div>
  );
}