"""
Chart components for the Vehicle Registration Dashboard
"""

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
from typing import List

def create_vehicle_type_chart(data: pd.DataFrame) -> go.Figure:
    """Create vehicle type distribution chart"""
    fig = px.bar(
        data, 
        x='vehicle_type', 
        y='registrations',
        title='Vehicle Category Registrations',
        color='vehicle_type',
        color_discrete_map={
            '2W': '#3B82F6',
            '3W': '#10B981', 
            '4W': '#F59E0B'
        }
    )
    
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16,
        showlegend=False
    )
    
    fig.update_xaxes(title_text="Vehicle Category")
    fig.update_yaxes(title_text="Registrations")
    
    return fig

def create_manufacturer_chart(data: pd.DataFrame) -> go.Figure:
    """Create top manufacturers chart"""
    fig = px.bar(
        data.head(10), 
        x='registrations', 
        y='manufacturer',
        orientation='h',
        title='Top 10 Manufacturers by Registrations',
        color='yoy_growth',
        color_continuous_scale='RdYlGn'
    )
    
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16,
        height=500
    )
    
    fig.update_xaxes(title_text="Registrations")
    fig.update_yaxes(title_text="Manufacturer")
    
    return fig

def create_trend_chart(data: pd.DataFrame) -> go.Figure:
    """Create trend analysis chart"""
    fig = go.Figure()
    
    colors = {'2W': '#3B82F6', '3W': '#10B981', '4W': '#F59E0B'}
    
    for vehicle_type in data['vehicle_type'].unique():
        type_data = data[data['vehicle_type'] == vehicle_type]
        fig.add_trace(go.Scatter(
            x=type_data['quarter'],
            y=type_data['registrations'],
            mode='lines+markers',
            name=vehicle_type,
            line=dict(color=colors.get(vehicle_type, '#666666'), width=3),
            marker=dict(size=8)
        ))
    
    fig.update_layout(
        title='Registration Trends by Vehicle Category',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16,
        xaxis_title='Quarter',
        yaxis_title='Registrations',
        hovermode='x unified'
    )
    
    return fig

def create_growth_comparison_chart(data: pd.DataFrame) -> go.Figure:
    """Create YoY vs QoQ growth comparison"""
    fig = px.scatter(
        data,
        x='qoq_growth',
        y='yoy_growth',
        size='registrations',
        color='vehicle_type',
        hover_name='manufacturer',
        title='Growth Analysis: YoY vs QoQ',
        color_discrete_map={
            '2W': '#3B82F6',
            '3W': '#10B981', 
            '4W': '#F59E0B'
        }
    )
    
    # Add quadrant lines
    fig.add_hline(y=0, line_dash="dash", line_color="gray", opacity=0.5)
    fig.add_vline(x=0, line_dash="dash", line_color="gray", opacity=0.5)
    
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16,
        xaxis_title='QoQ Growth (%)',
        yaxis_title='YoY Growth (%)'
    )
    
    return fig

def create_market_share_pie(data: pd.DataFrame) -> go.Figure:
    """Create market share pie chart"""
    fig = px.pie(
        data,
        values='registrations',
        names='manufacturer',
        title='Market Share by Manufacturer (Top 8)',
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16
    )
    
    return fig

def create_growth_heatmap(data: pd.DataFrame) -> go.Figure:
    """Create growth heatmap by manufacturer and vehicle type"""
    pivot_data = data.pivot(index='manufacturer', columns='vehicle_type', values='yoy_growth')
    
    fig = go.Figure(data=go.Heatmap(
        z=pivot_data.values,
        x=pivot_data.columns,
        y=pivot_data.index,
        colorscale='RdYlGn',
        text=pivot_data.values,
        texttemplate="%{text:.1f}%",
        textfont={"size": 10},
        colorbar=dict(title="YoY Growth %")
    ))
    
    fig.update_layout(
        title='YoY Growth Heatmap by Manufacturer & Vehicle Type',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font_color='white',
        title_font_size=16,
        xaxis_title='Vehicle Type',
        yaxis_title='Manufacturer'
    )
    
    return fig