"""
Vehicle Registration Analytics Dashboard
Built with Streamlit for investor analysis of Vahan Dashboard data
"""

import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
import numpy as np

# Import custom modules
from utils.data_processor import data_processor
from components.charts import (
    create_vehicle_type_chart,
    create_manufacturer_chart, 
    create_trend_chart,
    create_growth_comparison_chart,
    create_market_share_pie,
    create_growth_heatmap
)

# Page configuration
st.set_page_config(
    page_title="Vehicle Registration Analytics",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .insight-card {
        background-color: #e8f4fd;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #17a2b8;
    }
    .positive-growth {
        color: #28a745;
        font-weight: bold;
    }
    .negative-growth {
        color: #dc3545;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

def main():
    # Header
    st.markdown('<h1 class="main-header">🚗 Vehicle Registration Analytics Dashboard</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; color: #666; font-size: 1.1rem;">Investment Intelligence from Vahan Dashboard Data</p>', unsafe_allow_html=True)
    
    # Sidebar filters
    st.sidebar.header("📊 Dashboard Filters")
    
    # Date range selection
    st.sidebar.subheader("📅 Date Range")
    available_quarters = sorted(data_processor.df['quarter'].unique())
    selected_quarters = st.sidebar.multiselect(
        "Select Quarters",
        available_quarters,
        default=available_quarters[-2:]  # Last 2 quarters by default
    )
    
    # Vehicle type filter
    st.sidebar.subheader("🚙 Vehicle Categories")
    vehicle_types = ['2W', '3W', '4W']
    selected_vehicle_types = st.sidebar.multiselect(
        "Select Vehicle Types",
        vehicle_types,
        default=vehicle_types
    )
    
    # Manufacturer filter
    st.sidebar.subheader("🏭 Manufacturers")
    all_manufacturers = sorted(data_processor.df['manufacturer'].unique())
    selected_manufacturers = st.sidebar.multiselect(
        "Select Manufacturers (leave empty for all)",
        all_manufacturers,
        default=[]
    )
    
    # Filter data based on selections
    filtered_df = data_processor.df.copy()
    if selected_quarters:
        filtered_df = filtered_df[filtered_df['quarter'].isin(selected_quarters)]
    if selected_vehicle_types:
        filtered_df = filtered_df[filtered_df['vehicle_type'].isin(selected_vehicle_types)]
    if selected_manufacturers:
        filtered_df = filtered_df[filtered_df['manufacturer'].isin(selected_manufacturers)]
    
    # Main dashboard content
    if filtered_df.empty:
        st.error("No data available for the selected filters. Please adjust your selection.")
        return
    
    # Key Metrics Row
    st.header("📈 Key Performance Indicators")
    metrics = data_processor.get_summary_metrics(filtered_df)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Registrations",
            value=f"{metrics['total_registrations']:,}",
            delta=f"{metrics['avg_yoy_growth']:.1f}% YoY"
        )
    
    with col2:
        st.metric(
            label="Average YoY Growth",
            value=f"{metrics['avg_yoy_growth']:.1f}%",
            delta=f"{metrics['avg_qoq_growth']:.1f}% QoQ"
        )
    
    with col3:
        st.metric(
            label="Top Performer",
            value=metrics['top_performer'],
            delta=f"{metrics['top_performer_growth']:.1f}% YoY"
        )
    
    with col4:
        quarters_analyzed = len(selected_quarters) if selected_quarters else len(available_quarters)
        st.metric(
            label="Analysis Period",
            value=f"{quarters_analyzed} Quarters",
            delta="Live Data"
        )
    
    # Charts Section
    st.header("📊 Market Analysis")
    
    # Row 1: Vehicle Type and Manufacturer Analysis
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Vehicle Category Performance")
        vehicle_summary = data_processor.get_vehicle_type_summary(filtered_df)
        if not vehicle_summary.empty:
            fig_vehicle = create_vehicle_type_chart(vehicle_summary)
            st.plotly_chart(fig_vehicle, use_container_width=True)
            
            # Show data table
            st.dataframe(
                vehicle_summary[['vehicle_type', 'registrations', 'yoy_growth', 'qoq_growth', 'market_share']].round(1),
                use_container_width=True
            )
    
    with col2:
        st.subheader("Top Manufacturers")
        manufacturer_summary = data_processor.get_manufacturer_summary(filtered_df)
        if not manufacturer_summary.empty:
            fig_manufacturer = create_manufacturer_chart(manufacturer_summary)
            st.plotly_chart(fig_manufacturer, use_container_width=True)
    
    # Row 2: Trend Analysis
    st.subheader("📈 Registration Trends")
    trend_data = data_processor.get_trend_data(filtered_df)
    if not trend_data.empty:
        fig_trend = create_trend_chart(trend_data)
        st.plotly_chart(fig_trend, use_container_width=True)
    
    # Row 3: Advanced Analytics
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Growth Analysis")
        latest_quarter = filtered_df['quarter'].max()
        latest_data = filtered_df[filtered_df['quarter'] == latest_quarter]
        if not latest_data.empty:
            fig_growth = create_growth_comparison_chart(latest_data)
            st.plotly_chart(fig_growth, use_container_width=True)
    
    with col2:
        st.subheader("Market Share Distribution")
        if not manufacturer_summary.empty:
            fig_pie = create_market_share_pie(manufacturer_summary.head(8))
            st.plotly_chart(fig_pie, use_container_width=True)
    
    # Investment Insights Section
    st.header("💡 Investment Insights")
    insights = data_processor.get_investment_insights()
    
    for insight in insights:
        if insight['type'] == 'positive':
            st.success(f"**{insight['title']}**: {insight['description']}")
        elif insight['type'] == 'opportunity':
            st.info(f"**{insight['title']}**: {insight['description']}")
        else:
            st.info(f"**{insight['title']}**: {insight['description']}")
    
    # Growth Leaders Table
    st.header("🏆 Growth Leaders")
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Top YoY Performers")
        yoy_leaders = data_processor.get_growth_leaders('yoy_growth')
        st.dataframe(
            yoy_leaders[['manufacturer', 'vehicle_type', 'yoy_growth', 'registrations']].round(1),
            use_container_width=True
        )
    
    with col2:
        st.subheader("Top QoQ Performers") 
        qoq_leaders = data_processor.get_growth_leaders('qoq_growth')
        st.dataframe(
            qoq_leaders[['manufacturer', 'vehicle_type', 'qoq_growth', 'registrations']].round(1),
            use_container_width=True
        )
    
    # Raw Data Section (Expandable)
    with st.expander("📋 View Raw Data"):
        st.dataframe(filtered_df, use_container_width=True)
        
        # Download button
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="Download Data as CSV",
            data=csv,
            file_name=f"vehicle_registration_data_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: #666;'>
        <p>📊 Vehicle Registration Analytics Dashboard | Built with Streamlit</p>
        <p>Data simulated based on Vahan Dashboard patterns for demonstration purposes</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()